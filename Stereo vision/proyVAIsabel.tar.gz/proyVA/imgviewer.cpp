#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    cap = new VideoCapture(0);
    winSelected = false;

    grayImageI.create(240,320,CV_8UC1);
    grayImageD.create(240,320,CV_8UC1);
    trueDispImage.create(240,320,CV_8UC1);
    destGrayImage.create(240,320,CV_8UC1);

    cornersLeft.create(240, 320, CV_32FC1);
    fixedPoints.create(240, 320, CV_8UC1);
    disparity.create(240, 320, CV_32FC1);

    visorSI = new ImgViewer(&grayImageI, ui->imageFrameS);
    visorSD = new ImgViewer(&grayImageD, ui->imageFrameD);
    visorD = new ImgViewer(&destGrayImage, ui->imageFrame_3);
    visorTD = new ImgViewer(&trueDispImage, ui->imageFrame_4);

    connect(&timer,SIGNAL(timeout()),this,SLOT(compute()));
    connect(ui->captureButton,SIGNAL(clicked(bool)),this,SLOT(start_stop_capture(bool)));
    connect(ui->colorButton,SIGNAL(clicked(bool)),this,SLOT(change_color_gray(bool)));
    connect(visorSI,SIGNAL(windowSelected(QPointF, int, int)),this,SLOT(selectWindow(QPointF, int, int)));
    connect(visorSI,SIGNAL(pressEvent()),this,SLOT(deselectWindow()));
    // --------------------------------------------------------------------------------------------------
    connect(ui->loadImage,SIGNAL(clicked()),this,SLOT(loadImage()));
    connect(ui->disparity, SIGNAL(clicked()), this, SLOT(disparity()));
    timer.start(30);
}

MainWindow::~MainWindow()
{
    delete ui;
    delete cap;
    delete visorSI;
    delete visorSD;
    delete visorD;
    delete visorTD;
    grayImageD.release();
    grayImageI.release();
    trueDispImage.release();
    destGrayImage.release();
}

void MainWindow::compute()
{

    //Captura de imagen
    if(ui->captureButton->isChecked() && cap->isOpened())
    {
        *cap >> grayImageI;
        cv::resize(grayImageI, grayImageI, Size(320,240));
        cvtColor(grayImageI, grayImageI, COLOR_BGR2GRAY);
        //cvtColor(colorImage, colorImage, COLOR_BGR2RGB);

    }


    //En este punto se debe incluir el código asociado con el procesamiento de cada captura


    //Actualización de los visores

    if(winSelected)
        visorSI->drawSquare(QRect(imageWindow.x, imageWindow.y, imageWindow.width,imageWindow.height), Qt::green);

    visorSI->update();
    visorSD->update();
    visorD->update();
    visorTD->update();
}

void MainWindow::start_stop_capture(bool start)
{
    if(start)
        ui->captureButton->setText("Stop capture");
    else
        ui->captureButton->setText("Start capture");
}

void MainWindow::change_color_gray(bool color)
{
        ui->colorButton->setText("Color image");
        visorSD->setImage(&grayImageI);
}

void MainWindow::selectWindow(QPointF p, int w, int h)
{
    QPointF pEnd;
    if(w>0 && h>0)
    {
        imageWindow.x = p.x()-w/2;
        if(imageWindow.x<0)
            imageWindow.x = 0;
        imageWindow.y = p.y()-h/2;
        if(imageWindow.y<0)
            imageWindow.y = 0;
        pEnd.setX(p.x()+w/2);
        if(pEnd.x()>=320)
            pEnd.setX(319);
        pEnd.setY(p.y()+h/2);
        if(pEnd.y()>=240)
            pEnd.setY(239);
        imageWindow.width = pEnd.x()-imageWindow.x+1;
        imageWindow.height = pEnd.y()-imageWindow.y+1;

        winSelected = true;
    }
}

void MainWindow::deselectWindow()
{
    winSelected = false;
}

void MainWindow::loadImage(){
    start_stop_capture(false);
    disconnect(&timer,SIGNAL(timeout()),this,SLOT(compute()));
    ui->captureButton->setChecked(false);
    QStringList fileName = QFileDialog::getOpenFileNames(this,
                                                    "Load an Image",
                                                    "/home/",
                                                    "Image Files (*.png *.jpg)");
    const std::string file  = fileName[0].toStdString();
    const std::string file2 = fileName[1].toStdString();

    if(fileName.size() > 1){
        cv::Mat img = cv::imread(file, IMREAD_COLOR);
        cv::Mat img2 = cv::imread(file2, IMREAD_COLOR);
        cv::resize(img, img, Size(320,240));
        cv::resize(img2, img2, Size(320,240));
        cvtColor(img, img, COLOR_BGR2RGB);
        cvtColor(img2, img2, COLOR_BGR2RGB);
        cvtColor(img, grayImageI, COLOR_RGB2GRAY);
        cvtColor(img, grayImageD, COLOR_RGB2GRAY);
    } else{
        start_stop_capture(true);
        ui->captureButton->setChecked(true);
    }
    connect(&timer,SIGNAL(timeout()),this,SLOT(compute()));
}

std::vector<std::vector<float>> MainWindow::corners(Mat img){
    fixedPoints.setTo(0);
    disparity.setTo(0);

    Mat imgHarris;
    cornerHarris(img, imgHarris, 5, 3, 0.04);
    // Supresion del no máximo
    Mat sorted;
    std::vector<std::vector<float>> puntos;

    for( int i = 0; i < imgHarris.rows ; i++ )
    {
        for( int j = 0; j < imgHarris.cols; j++ )
        {
            if(imgHarris.at<float>(i,j) > 0.00001)
            {
                std::vector<float> aux;
                float valor = imgHarris.at<float>(i,j);
                aux.push_back(i+0.);
                aux.push_back(j+0.);
                aux.push_back(valor);
                puntos.push_back(aux);
            }
        }
    }

    // Ordenamos el vector de puntos
    std::sort(puntos.begin(), puntos.end(), [](const std::vector<float>& a, const std::vector<float>& b) {
        return a[2] > b[2];
    });

    // Recorremos el vector ordenado
    for(int i = 0; i < puntos.size(); i++)
    {
        // miramos los vecinos con la distancia euclídea
        for(int j = i+1; j < puntos.size(); j++)
        {
            float result = sqrt(pow(puntos[i][0]-puntos[j][0],2)+ pow(puntos[i][1]-puntos[j][1],2));
            if (result <= 13/2.)
            {
                puntos.erase(puntos.begin()+j);
                j--;
            }
        }
    }

    return puntos;
}

void MainWindow::compareCorners(std::vector<std::vector<float>> puntosIzda, std::vector<std::vector<float>> puntosDcha){
    // Pasamos a comprobar los puntos que obtenemos de la imagen izquierda con la imagen derecha
    Mat result;
    int w = 11;
    Mat aux;
    grayImageI.copyTo(aux);
    aux.setTo(0);
    for(int i = 0; i < puntosDcha.size(); i++){
        aux.at<uchar>(puntosDcha[i][0],puntosDcha[i][1]) = 1;
    }

    for(int i = 0; i < puntosIzda.size(); i++){
        for (int j = 0; j < aux.cols; j++) {
            Point pDcha(j, puntosIzda[i][0]);  //PILAR (06/05): el punto que hay que consultar de la imagen derecha es el que tiene columna j y la misma fila que la esquina izquierda
            //if(aux.at<uchar>(puntosDcha[j][0],puntosDcha[j][1]) == 1){
            if(aux.at<uchar>(pDcha)==1){  //PILAR(06/05)

                Mat left = grayImageI(Rect(puntosIzda[i][1]-w/2, puntosIzda[i][0]-w/2, w, w));
                Mat right = destGrayImage(Rect(pDcha.x-w/2, pDcha.y-w/2, w, w)); // PILAR (06/05): ventana centrada en la esquina de la derecha
                //Mat right = destGrayImage(Rect(puntosIzda[i][1]-w/2, puntosDcha[j][0]-w/2, w, w)); //PILAR (06/05): la definición de la ventana no es correcta
                matchTemplate(right, left, result, TM_CCOEFF_NORMED);

                float best = 0; //PILAR (06/05): esta definición hay que hacerla antes del bucle de la línea 211
                Point bestP; //PILAR (06/05): esta definición hay que hacerla antes del bucle de la línea 211

                //PILAR (06/05): este bucle no es correcto. Hay que comprobar si el único elemento de result contiene un valor superior a best
                //PILAR (06/05): en tal caso se actualiza best y bestP
//                for (int x=puntosDcha[i][1]-w/2; x < result.cols; x++) {
//                    for(int y= 320; y < result.cols; y++){
//                        if(result.at<float>(x,y) > best and result.at<float>(x,y) > 0.8){
//                            best = result.at<float>(x,y);
//                            bestP.x = x;
//                            bestP.y = y;
//                        }
//                    }
//                }

                //PILAR (06/05): las dos siguiente líneas se incluyen después del bucle de las líneas 211-241
                //PILAR (06/05): sólo se deben ejecutar si best supera el umbral de 0.8
                fixedPoints.at<uchar>(bestP) = 1;
                disparity.at<float>(puntosIzda[i][0], puntosIzda[i][1]) = puntosIzda[i][0]-puntosDcha[bestP.x][bestP.y];
            }
        }
    }
}

void MainWindow::segmentation(){
 /*   Rect minRect;
    Point actual;
    int lo = 1 == 0 ? 0 : 20;
    int up = 1 == 0 ? 0 : 20;
    Mat imgSegmented;
    if(!isColor)
        grayImage.copyTo(imgSegmented);
    else
        colorImage.copyTo(imgSegmented);

    // Lanzamos el crecimiento de regiones
    for (int i = 0; i < imgSegmented.rows; i++) {
        for (int j = 0; j < imgSegmented.cols; j++) {
            if(imgRegiones.at<int>(i,j) == -1 and imgMask.at<uchar>(i+1,j+1) == 0){
                grisMedio = 0;
                rgb[0]=0;
                rgb[1]=0;
                rgb[2]=0;
                actual.x = j;
                actual.y = i;

                // flag fijo
                int flag = 4|  (1 << 8)| FLOODFILL_MASK_ONLY;

                cv::floodFill(imgSegmented, imgMask, actual, lo, &minRect, Scalar(lo, lo, lo), Scalar(up, up, up), flag);
                puntos = 0;
                for (int x = 0; x < minRect.width; x++) {
                    for(int y = 0; y < minRect.height; y++){
                        int auxX = minRect.x + x;
                        int auxY = minRect.y + y;
                        if(imgRegiones.at<int>(auxY,auxX) == -1 and imgMask.at<uchar>(auxY+1, auxX+1) == 1){
                            imgRegiones.at<int>(auxY,auxX) = idReg;
                            puntos++;
                            rgb[0] += colorImage.at<Vec3b>(Point(auxX,auxY))[0];
                            rgb[1] += colorImage.at<Vec3b>(Point(auxX,auxY))[1];
                            rgb[2] += colorImage.at<Vec3b>(Point(auxX,auxY))[2];
                            grisMedio += grayImage.at<uchar>(Point(auxX,auxY));
                        }
                    }
                }
                addListRegiones(actual);
                idReg++;
            }
        }
    }

    // post-procesamiento
    if(!isColor){
        for (int i = 0; i < grayImage.rows; i++) {
            for (int j = 0; j < grayImage.cols; j++) {
                int min = 256;
                int regionAux = -999;
                if(imgRegiones.at<int>(i,j) == -1){
                    // comparamos con los vecinos
                    int value = grayImage.at<uchar>(i,j);
                    for (int v = i-1; v < i+2; v++) {
                        for (int v2 = j-1; v2 < j+2; v2++) {
                           if((grayImage.cols > v2) and (v2 > -1) and (grayImage.rows > v)  and (v > -1)
                                    and min > abs(value - grayImage.at<uchar>(v, v2))
                                    and imgRegiones.at<int>(v, v2) != -1){
                                min       = abs(value - grayImage.at<uchar>(v, v2));
                                regionAux = imgRegiones.at<int>(v, v2);
                            }
                        }
                    }
                    imgRegiones.at<int>(i,j) = regionAux;
                    listRegiones[regionAux].nPuntos++;
                }
            }
        }
    } else {
        for (int i = 0; i < colorImage.rows; i++) {
            for (int j = 0; j < colorImage.cols; j++) {
                int minR = 256;
                int minG = 256;
                int minB = 256;
                int regionAux = -999;
                if(imgRegiones.at<int>(i,j) == -1){
                    Vec3b value = colorImage.at<Vec3b>(i,j);
                    for (int v = i-1; v < i+2; v++) {
                        for (int v2 = j-1; v2 < j+2; v2++) {
                           Vec3b actual = colorImage.at<Vec3b>(v,v2);
                           if((colorImage.cols > v2) and (v2 > -1) and (colorImage.rows > v)  and (v > -1)
                                    and minR > abs(value[0] - actual[0])
                                    and minG > abs(value[1] - actual[1])
                                    and minB > abs(value[2] - actual[2])
                                    and imgRegiones.at<int>(v, v2) != -1){
                                minR       = abs(value[0] - actual[0]);
                                minG       = abs(value[1] - actual[1]);
                                minB       = abs(value[2] - actual[2]);
                                regionAux = imgRegiones.at<int>(v, v2);
                            }
                        }
                    }
                    imgRegiones.at<int>(i,j) = regionAux;
                    listRegiones[regionAux].nPuntos++;
                }
            }
        }
    }


    // Vemos las fronteras
        bool stop = false;
        for (int i = 0; i < imgSegmented.rows; i++) {
            for (int j = 0; j < imgSegmented.cols; j++) {
                int valueReg = imgRegiones.at<int>(i,j);
                stop = false;

                if(i > 0 and j > 0 and i < imgRegiones.rows and j < imgRegiones.cols){
                    // vecino 1
                    if(valueReg != imgRegiones.at<int>(i-1, j-1) and i > 0 and j > 0 and i < imgRegiones.rows and j < imgRegiones.cols){
                            listRegiones[imgRegiones.at<int>(i, j)].frontera.push_back(Point(j,i));
                            stop = true;
                            continue;
                    }
                    // vecino 2
                    if(valueReg != imgRegiones.at<int>(i-1, j) and i > 0 and j >= 0 and i < imgRegiones.rows and j < imgRegiones.cols){
                            listRegiones[imgRegiones.at<int>(i, j)].frontera.push_back(Point(j,i));
                            stop = true;
                            continue;
                    }
                    // vecino 3
                    if(valueReg != imgRegiones.at<int>(i-1, j+1) and i > 0 and j >= 0 and i < imgRegiones.rows and j < imgRegiones.cols-1){
                            listRegiones[imgRegiones.at<int>(i, j)].frontera.push_back(Point(j,i));
                            stop = true;
                            continue;
                    }
                    // vecino 4
                    if(valueReg != imgRegiones.at<int>(i, j-1) and i >= 0 and j > 0 and i < imgRegiones.rows and j < imgRegiones.cols){
                            listRegiones[imgRegiones.at<int>(i, j)].frontera.push_back(Point(j,i));
                            stop = true;
                            continue;
                    }
                    // vecino 5
                    if(valueReg != imgRegiones.at<int>(i, j+1) and i >= 0 and j >= 0 and i < imgRegiones.rows and j < imgRegiones.cols-1){
                            listRegiones[imgRegiones.at<int>(i, j)].frontera.push_back(Point(j,i));
                            stop = true;
                            continue;
                    }
                    // vecino 6
                    if(valueReg != imgRegiones.at<int>(i+1, j-1) and i >= 0 and j > 0 and i < imgRegiones.rows and j < imgRegiones.cols){
                            listRegiones[imgRegiones.at<int>(i, j)].frontera.push_back(Point(j,i));
                            stop = true;
                            continue;
                    }
                    // vecino 7
                    if(valueReg != imgRegiones.at<int>(i+1, j) and i >= 0 and j > 0 and i < imgRegiones.rows and j < imgRegiones.cols){
                            listRegiones[imgRegiones.at<int>(i, j)].frontera.push_back(Point(j,i));
                            stop = true;
                            continue;
                    }
                    // vecino 8
                    if(valueReg != imgRegiones.at<int>(i+1, j+1) and i >= 0 and j >= 0 and i < imgRegiones.rows and j < imgRegiones.cols-1){
                            listRegiones[imgRegiones.at<int>(i, j)].frontera.push_back(Point(j,i));
                            stop = true;
                            continue;
                    }
                }
            }
        }


        // pintamos los resultados
        for (int i = 0; i < imgRegiones.rows; i++) {
            for (int j = 0; j < imgRegiones.cols; j++) {
                if(listRegiones.size() > imgRegiones.at<int>(i,j)){
                        destGrayImage.at<uchar>(i,j) = listRegiones[imgRegiones.at<int>(i,j)].gMedio;
                        destColorImage.at<Vec3b>(i,j) = listRegiones[imgRegiones.at<int>(i,j)].rgbMedio;
                    }
            }
        }*/
}

void MainWindow::addListRegiones(Point actual){
   /* region aux;
    aux.pInicio = actual;
    aux.nPuntos = puntos;
    aux.gMedio  = grisMedio/puntos;
    std::vector<Point> list;
    aux.frontera = list;
    aux.rgbMedio[0] = rgb[0]/puntos;
    aux.rgbMedio[1] = rgb[1]/puntos;
    aux.rgbMedio[2] = rgb[2]/puntos;
    listRegiones.push_back(aux);*/
}

void MainWindow::iniciar_disparity(){
    std::vector<std::vector<float>> pizda = corners(grayImageI);
    std::vector<std::vector<float>> pdcha = corners(grayImageD);
    compareCorners(pizda, pdcha);
}
